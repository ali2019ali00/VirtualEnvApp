package com.manus.virtualenv

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.manus.virtualenv.databinding.ActivityMainBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ClonedAppsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupFab()
        
        // Check for Overlay Permission (Required for Game Guardian)
        checkOverlayPermission()
    }

    private fun setupRecyclerView() {
        adapter = ClonedAppsAdapter { app ->
            launchApp(app)
        }
        binding.recyclerView.layoutManager = GridLayoutManager(this, 4)
        binding.recyclerView.adapter = adapter
        
        // Load cloned apps (mock data for now)
        loadClonedApps()
    }

    private fun setupFab() {
        binding.fabAdd.setOnClickListener {
            val intent = Intent(this, AppListActivity::class.java)
            startActivity(intent)
        }
    }

    private fun launchApp(app: ClonedApp) {
        // Logic to launch app inside virtual environment
        // VirtualCore.get().launchApp(app.packageName)
    }

    private fun loadClonedApps() {
        // Logic to load apps already cloned into the virtual environment
    }
    
    private fun checkOverlayPermission() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            val intent = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            startActivity(intent)
        }
    }
}

data class ClonedApp(val name: String, val packageName: String, val icon: Int)
