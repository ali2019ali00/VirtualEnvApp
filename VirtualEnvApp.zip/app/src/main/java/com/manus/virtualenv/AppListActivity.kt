package com.manus.virtualenv

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.manus.virtualenv.databinding.ActivityAppListBinding

class AppListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppListBinding
    private lateinit var adapter: AppListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        loadInstalledApps()
    }

    private fun setupRecyclerView() {
        adapter = AppListAdapter { app ->
            cloneApp(app)
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val filteredApps = apps.filter { app ->
            (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0
        }
        adapter.submitList(filteredApps)
    }

    private fun cloneApp(app: ApplicationInfo) {
        // Logic to clone app into virtual environment
        // VirtualCore.get().installApp(app.packageName)
        finish()
    }
}
