package com.manus.virtualenv

import android.content.pm.ApplicationInfo
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppListAdapter(private val onAddClick: (ApplicationInfo) -> Unit) :
    RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    private var apps = mutableListOf<ApplicationInfo>()

    fun submitList(newApps: List<ApplicationInfo>) {
        apps.clear()
        apps.addAll(newApps)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_list, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.bind(app)
        holder.itemView.findViewById<View>(R.id.btnAdd).setOnClickListener { onAddClick(app) }
    }

    override fun getItemCount() = apps.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val icon: ImageView = view.findViewById(R.id.appIcon)
        private val name: TextView = view.findViewById(R.id.appName)
        private val pkg: TextView = view.findViewById(R.id.appPackage)

        fun bind(app: ApplicationInfo) {
            val pm = itemView.context.packageManager
            name.text = app.loadLabel(pm)
            pkg.text = app.packageName
            // icon.setImageDrawable(app.loadIcon(pm))
        }
    }
}
